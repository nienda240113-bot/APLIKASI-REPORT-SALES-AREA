
/*
  GOOGLE APPS SCRIPT BACKEND (Simpan di Apps Script Editor & Deploy as Web App)
  Pastikan akses 'Who has access' diset ke 'Anyone'.
*/

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);
  
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Jika sheet masih kosong, buat header
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Timestamp", "Periode", "WH", "AM", "AC", "Store Code / Name", "Shift",
        "Actual Sales", "Target MTD", "Achieve MTD (%)", "Fee Base"
      ]);
    }
    
    sheet.appendRow([
      new Date(),
      data.periode,
      data.wh,
      data.am,
      data.ac,
      data.storeCodeName,
      data.shift,
      data.revenue.actualSales,
      data.revenue.targetMtd,
      data.revenue.achieveMtd,
      data.feeBase
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({"status": "success"})).setMimeType(ContentService.MimeType.JSON);
  } catch (f) {
    return ContentService.createTextOutput(JSON.stringify({"status": "error", "message": f.toString()})).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}
